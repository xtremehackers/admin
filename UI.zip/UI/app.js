var app = angular.module('app', [
    'ui.router',
    'angular-loading-bar',
    'ngResource',
    'ui.bootstrap',
    'localytics.directives'
]);